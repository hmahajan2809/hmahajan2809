#ifndef _ATMO_CONFIG_H_
#define _ATMO_CONFIG_H_

//
// Static core configuration
//  
// If this is defined, the Nimbus Core will not use malloc or free. Given the risks of dynamic allocation on embedded systems, this is generally a good idea.
//
// #define ATMO_STATIC_CORE
// #define ATMO_STATIC_SIZE

// Platform does not have sscanf() support
// #define ATMO_PLATFORM_NO_SSCANF_SUPPORT 

//  Platform does not have double support 
// #define ATMO_PLATFORM_NO_DOUBLE_SUPPORT

//  Platform does not have float support 
// #define ATMO_PLATFORM_NO_FLOAT_SUPPORT

//  Platform does not have sprintf support 
// #define ATMO_PLATFORM_NO_SPRINTF_SUPPORT

// Platform does not have sprintf float support (some platforms' sprintf implementation doesn't support floats)
// #define ATMO_NO_SPRINTF_FLOAT_SUPPORT

//  If a platform doesn't have sprint float support, it may have dtostrf support instead 
//  NOTE: If a platform has neither float nor dtostrf support, 2 decimal fixed point will be used with integer sprintf 
// #define ATMO_NO_DTOSTRF_SUPPORT

//  Use custom fast sqrt implementation instead of built in sqrt 
//  this saves a little bit of flash space 
// #define ATMO_FAST_SQRT

//  Remove non-necessary prints, make buffers as small as possible to preserve the maximum amount of flash space 
//  Do not enable unless absolutely necessary 
//#define ATMO_SLIM_STACK

//  Platform doesn't support strtoul 
// #define ATMO_NO_STRTOUL_SUPPORT

//  Size of Cloud TCP Driver Queue for Cloud Events 
// #define ATMO_CLOUD_TCP_QUEUE_SIZE 10

//  Minimum baud rate a platform can support 
// #define ATMO_UART_MIN_BAUD 9600

#endif